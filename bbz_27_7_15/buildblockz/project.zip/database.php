<?php
	$link=mysqli_connect('localhost','u411650325_rk','.9430103099r','u411650325_rk');
	 
	if(mysqli_connect_errno($link)){
			echo 'Failed to connect';
	}
?>