<?php
include 'header.php';
?>
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<div class="container">
	<div class="row">
		<div class="col-md-12 ">

			<h3>
			<center>
				About Us
			</center></h3>

		</div>
	</div>
</div>

<section style="background: black;padding-top:100px; padding-bottom: 100px;color:white;">
	<h4 class="text-center"> Fixing up a meeting is now simpler than ever! </h4>
	<div class="container">
		<div class="row">
			<div class="col-md-5">
				<br />
				<br />
				<br />

				<p>
					You like a particular Builder/Contractor?
				</p>

				<p>
					Want to fix up a meeting?
				</p>
				<ul>
					<li>
						<p>
							It’s all a CLICK away!
						</p>
					</li>
				</ul>

			</div>
			<div class="col-md-7">
				<img width="90%" height="90%" src="images/FixUpameeting2.png" />
			</div>
		</div>
	</div>

</section>
<br />
<br />
<br />
<br />
<br />
<br />
<section style="">
	<div class="container">
		<div class="row">
			<div class="col-md-7">
				<img width="90%" height="90%" src="images/Searchmadeeasy.png" />
			</div>
			<div class="col-md-5">
				<p>
					Search made easy!
				</p>
				<ul>
					<li>
						<p>
							Search the largest online database of Builder/Contractor listings
						</p>
					</li>
					<li>
						<p>
							Enter City Name, Builder/Contractor Name
						</p>
					</li>
				</ul>

			</div>

		</div>
	</div>
</section>
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />

<?php
include 'footer.php';
?>