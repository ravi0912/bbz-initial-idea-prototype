<?php
/**
 * MySQL Database Server Address
 */
define("DB_SERVER","localhost");



/**
 * MySQL Database Username
 */
define("DB_USERNAME","u411351664_rk");

/**
 * MySQL Database Password
 */
define("DB_PASSWORD",".9430103099r");

/**
 * DATABASE NAME of the System
 */
define("DB_NAME","u411351664_build");
?>