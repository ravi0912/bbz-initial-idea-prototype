<?php
	$thispage='siteLogin';
	include 'header.php';
	?>
	<div class='container'>
		<br /><br /><br /><br /><br /><br /><br />
		<div class="row">
					        	<div id="login_signup_update"></div>
					        	<a class="close" data-dismiss="modal">×</a>
					        </div>
		<?php
			include 'loginForm.php';
			?>
	</div>
	
<?php
	include 'footer.php';
	?>
