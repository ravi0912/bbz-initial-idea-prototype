<?php
  include 'header.php';
?>
<html>
	<body>
</br></br></br></br></br>
	<p><i>Please, Verify your account from your given email id.</i><p>
	</body>

<?php
  include 'footer.php';
?>