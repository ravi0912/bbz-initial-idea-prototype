
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/rateit.css" media="all" rel="stylesheet" type="text/css"/>

    <script src="js/jquery.rateit.js" type="text/javascript"></script>
    <script src="js/jquery.rateit.min.js" type="text/javascript"></script>
    	
<div class="rateit" data-rateit-value="<?php echo $rating;?>" data-rateit-ispreset="true" data-rateit-readonly="true"></div>
