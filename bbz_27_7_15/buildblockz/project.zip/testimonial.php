<?php
include 'header.php';
?>
<link href='http://fonts.googleapis.com/css?family=Bad+Script' rel='stylesheet' type='text/css'>
<style>
	.testimonial{
		font-family: 'Bad Script', cursive;
		font-size: 20px;
		margin:20px;
		padding:5px;
		border-left:5px solid #dedede;
		display:block;
	}
</style>
<br/>
<br/>
<br/>
<br/>
<br/><br />
<hr />
<br /><br />
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<span class="testimonial">
				awdlmam
			</span>
			<span class="testimonial">
				awdlmam
			</span>
			<span class="testimonial">
				awdlmam
			</span><br />
		</div>
	</div>
</div>

<?php
include 'footer.php';
?>